 package com.example.statusbarnotificationsample;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


 public class MainActivity extends Activity {

	Button send_notification_bt,cancel_notification_bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        send_notification_bt = (Button) findViewById(R.id.send_notification_bt);
        cancel_notification_bt = (Button) findViewById(R.id.cancel_notification_bt);
        
        send_notification_bt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				showNotification();
				
			}
		});
        
        cancel_notification_bt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				cancelNotification(0);
			}
		});
        
    }
    
    public void showNotification(){

       
        // intent is used here to jump to specific activity
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        
        //Pending Intent is used when you click on notification and want to start some activity.
        PendingIntent pIntent = PendingIntent.getActivity(MainActivity.this, 0, intent, 0);

        //Here we are building notification to show to the user, it will be shown to user once user click on send notification button

        Notification mNotification=null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {

             mNotification = new Notification.Builder(this)

                    //Here we are setting the titile of Notification
                    .setContentTitle("Notification")
                            //Here we are adding subject message for notification
                    .setContentText("Subject Message for Notification")
                            //setSmallIcon metod is used to set some image in drawable
                    .setSmallIcon(R.drawable.ic_launcher)
                            //set pending intent using setContentIntent() method and by passing pending Intent object
                    .setContentIntent(pIntent)
                    .addAction(R.drawable.ic_launcher, "View", pIntent)
                    .setAutoCancel(true)
                    .addAction(0, "cancel", pIntent)
                    .build();

        } else {

            mNotification = new NotificationCompat.Builder(this)
                    .setContentTitle("Notification")
                    .setContentText("Subject Message for Notification")
                    .setTicker("Notify!")
                    .setContentIntent(pIntent)
                    .setDefaults(Notification.DEFAULT_SOUND)
                    .setAutoCancel(true)
                    .setSmallIcon(R.drawable.ic_launcher)
                    .build();

        }



        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // If you want to hide the notification after it was selected, do the code below
        // myNotification.flags |= Notification.FLAG_AUTO_CANCEL;

        notificationManager.notify(0, mNotification);
    }
    
    public void cancelNotification(int notificationId){



            NotificationManager nMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
           //cancel method is used to cancel the notification
            nMgr.cancel(notificationId);
        }
    }

    

