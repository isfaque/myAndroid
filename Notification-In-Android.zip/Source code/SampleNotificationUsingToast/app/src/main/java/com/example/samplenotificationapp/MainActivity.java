package com.example.samplenotificationapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

	Button show_long_toast_button;
	Button show_short_toast_button;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		show_long_toast_button = (Button) findViewById(R.id.show_long_toast_bt);
		show_short_toast_button = (Button) findViewById(R.id.show_short_toast_bt);

		show_long_toast_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Button is clicked: Long Toast",
						Toast.LENGTH_LONG).show();
			}
		});


		show_short_toast_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Button is clicked: Short Toast",
						Toast.LENGTH_SHORT).show();
			}
		});
	}




}
